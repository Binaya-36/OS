#include "screen.h"
#include "interrupts.h"
#include "keyboard.h"
#include "mouse.h"
#include "../memory/memory.h"
#include "../scheduler/scheduler.h"

static int stringEquals(const char* a, const char* b)
{
    int i = 0;
    while(a[i] != '\0' && b[i] != '\0')
    {
        if(a[i] != b[i]) return 0;
        i++;
    }
    return a[i] == b[i];
}

static void showMenu()
{
    printString("+---------------------------------------+");
    printString("|   NetNinjas OS  -  Commands           |");
    printString("+---------------------------------------+");
    printString("|  help   - Show this menu              |");
    printString("|  memory - Memory status               |");
    printString("|  procs  - Process status              |");
    printString("|  mouse  - Mouse position              |");
    printString("|  team   - Team info                   |");
    printString("|  clear  - Clear screen                |");
    printString("|  alloc  - Test memory allocation      |");
    printString("+---------------------------------------+");
}

void handleCommand(char* command)
{
    if(stringEquals(command, "help"))
    {
        showMenu();
    }
    else if(stringEquals(command, "memory"))
    {
        printMemoryStatus();
    }
    else if(stringEquals(command, "procs"))
    {
        printProcessStatus();
    }
    else if(stringEquals(command, "mouse"))
    {
        int mx = getMouseX();
        int my = getMouseY();
        printString("+---------------------------------------+");
        printString("|   NetNinjas OS  -  Mouse Status       |");
        printString("+---------------------------------------+");
        printStringNoNewLine("|  X position : ");
        if(mx >= 10) printChar((char)('0' + mx / 10));
        else          printChar('0');
        printChar((char)('0' + mx % 10));
        printString("                         |");
        printStringNoNewLine("|  Y position : ");
        if(my >= 10) printChar((char)('0' + my / 10));
        else          printChar('0');
        printChar((char)('0' + my % 10));
        printString("                         |");
        printStringNoNewLine("|  Left btn   : ");
        printString(getMouseLeft()  ? "pressed                |" : "not pressed            |");
        printStringNoNewLine("|  Right btn  : ");
        printString(getMouseRight() ? "pressed                |" : "not pressed            |");
        printString("+---------------------------------------+");
    }
    else if(stringEquals(command, "team"))
    {
        printString("+---------------------------------------+");
        printString("|   NetNinjas OS  -  Team Info          |");
        printString("+---------------------------------------+");
        printString("|  Team  : Net Ninjas                   |");
        printString("|  Members:                             |");
        printString("|    >> Ayusha                          |");
        printString("|    >> Binaya                          |");
        printString("|    >> Prijina                         |");
        printString("+---------------------------------------+");
    }
    else if(stringEquals(command, "clear"))
    {
        clearScreen();
        printStringNoNewLine("> ");
    }
    else if(stringEquals(command, "alloc"))
    {
        printString("Allocating 4 KB...");
        void* mem = allocateMemory(4096);
        if(mem != 0)
        {
            printString("Allocation successful!");
            printMemoryStatus();
            freeMemory(mem);
            printString("Memory freed.");
        }
        else
        {
            printString("ERROR: allocation failed!");
        }
    }
    else
    {
        printStringNoNewLine("Unknown command: '");
        printStringNoNewLine(command);
        printString("'  (type 'help')");
    }
}

extern "C" void kernelMain(void* multiboot_structure, unsigned int magicNumber)
{
    (void)multiboot_structure;
    (void)magicNumber;

    clearScreen();

    // Welcome banner - kept short so it stays on screen
    printString("+===========================================+");
    printString("|                                           |");
    printString("|    WELCOME TO NET NINJAS OS               |");
    printString("|    Team: Ayusha  Binaya  Prijina          |");
    printString("|                                           |");
    printString("+===========================================+");
    printString("");

    InterruptManager interrupts;
    printString("  [OK] Interrupts ready.");

    initMemory();
    printString("  [OK] Memory manager ready.");

    initScheduler();
    char p1[] = "Music Player";
    char p2[] = "File Manager";
    char p3[] = "Text Editor";
    addProcess(p1, 1);
    addProcess(p2, 2);
    addProcess(p3, 3);
    printString("  [OK] Scheduler ready. 3 processes loaded.");

    setCommandHandler(&handleCommand);
    printString("  [OK] Keyboard driver ready.");

    initMouse();
    printString("  [OK] Mouse driver ready.");

    printString("");
    printString("+===========================================+");
    printString("|   NetNinjas OS is ready!                 |");
    printString("|   Type 'help' to see all commands.       |");
    printString("+===========================================+");
    printString("");
    printStringNoNewLine("> ");

    while(1) {}
}
