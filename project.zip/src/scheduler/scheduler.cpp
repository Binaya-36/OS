#include "scheduler.h"
#include "../kernel/screen.h"

#define MAX_PROCESSES   10
#define PROCESS_FREE     0
#define PROCESS_READY    1
#define PROCESS_RUNNING  2
#define PROCESS_BLOCKED  3

struct Process
{
    int  id;
    int  state;
    int  priority;
    char name[32];
    int  timeSlice;
    int  ticksLeft;
    int  timeUsed;
};

static Process processes[MAX_PROCESSES];
static int currentProcess = 0;
static int activeCount    = 0;

void initScheduler()
{
    for(int i = 0; i < MAX_PROCESSES; i++)
    {
        processes[i].state     = PROCESS_FREE;
        processes[i].id        = -1;
        processes[i].ticksLeft = 0;
        processes[i].timeUsed  = 0;
    }
    currentProcess = 0;
    activeCount    = 0;
}

int addProcess(char* name, int priority)
{
    for(int i = 0; i < MAX_PROCESSES; i++)
    {
        if(processes[i].state == PROCESS_FREE)
        {
            processes[i].id        = i;
            processes[i].state     = PROCESS_READY;
            processes[i].priority  = priority;
            processes[i].timeSlice = priority * 5;
            processes[i].ticksLeft = processes[i].timeSlice;
            processes[i].timeUsed  = 0;

            int j = 0;
            while(name[j] != '\0' && j < 31)
            {
                processes[i].name[j] = name[j];
                j++;
            }
            processes[i].name[j] = '\0';

            activeCount++;
            return processes[i].id;
        }
    }
    return -1;
}

void schedule()
{
    if(activeCount == 0) return;

    if(processes[currentProcess].state == PROCESS_RUNNING)
    {
        processes[currentProcess].ticksLeft--;
        processes[currentProcess].timeUsed++;
        if(processes[currentProcess].ticksLeft > 0)
            return;
        processes[currentProcess].state     = PROCESS_READY;
        processes[currentProcess].ticksLeft = processes[currentProcess].timeSlice;
    }

    int bestIdx      = -1;
    int bestPriority = -1;

    for(int i = 0; i < MAX_PROCESSES; i++)
    {
        if(processes[i].state == PROCESS_READY && processes[i].priority > bestPriority)
        {
            bestPriority = processes[i].priority;
            bestIdx      = i;
        }
    }

    if(bestIdx != -1)
    {
        currentProcess                  = bestIdx;
        processes[currentProcess].state = PROCESS_RUNNING;
    }
}

static void printNum(int n)
{
    if(n == 0) { printChar('0'); return; }
    char buf[12];
    int i = 0;
    while(n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    for(int k = i - 1; k >= 0; k--) printChar(buf[k]);
}

void printProcessStatus()
{
    printString("  +---------------------------------------+");
    printString("  |   NetNinjas OS  -  Process Status     |");
    printString("  +---------------------------------------+");

    int found = 0;
    for(int i = 0; i < MAX_PROCESSES; i++)
    {
        if(processes[i].state != PROCESS_FREE)
        {
            found = 1;
            printStringNoNewLine("  |  [");
            printNum(processes[i].id);
            printStringNoNewLine("] ");
            printStringNoNewLine(processes[i].name);
            printStringNoNewLine("  Pri:");
            printNum(processes[i].priority);
            printStringNoNewLine("  ");
            if(processes[i].state == PROCESS_RUNNING)
                printString("RUNNING          |");
            else if(processes[i].state == PROCESS_READY)
                printString("READY            |");
            else
                printString("BLOCKED          |");
        }
    }
    if(!found) printString("  |  No active processes.                |");
    printString("  +---------------------------------------+");
}
