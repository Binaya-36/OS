#ifndef SCHEDULER_H
#define SCHEDULER_H

void initScheduler();
int addProcess(char* name, int priority);
void schedule();
void printProcessStatus();

#endif